# Aditya-L1 Solar Flare Nowcast & Forecast System

**ISRO Bharatiya Antariksh Hackathon 2026 — Problem Statement 15**

A two-part solar-flare system built around real Aditya-L1 observations:

- **Nowcast:** detects and physically characterizes flares in real time.
- **Forecast:** estimates whether a significant flare will start in the next 30 minutes.

The pipeline is designed around real **SoLEXS (2.8–20 keV)** and **HEL1OS (20–150 keV)** observations and ISRO CALDB ARF/RMF calibration files. No synthetic light curves or GOES XRS data are substituted for the Aditya-L1 measurements.

## Repository structure

```text
.
├── nowcast/
│   ├── io_data.py       # finding, extracting and reading instrument files
│   ├── detection.py     # Poisson-FOCuS flare detection
│   ├── physics.py       # spectral/physical characterization
│   ├── analysis.py      # event analysis and cross-checks
│   ├── reports.py       # report generation
│   ├── pipeline.py      # nowcast pipeline orchestration
│   ├── common.py        # shared configuration/helpers
│   ├── api.py           # public nowcast interface
│   └── run.py           # nowcast entry point
│
├── forecast/
│   ├── data.py          # per-day data assembly
│   ├── features.py      # physics-informed feature extraction
│   ├── windowing.py     # training windows and labels
│   ├── models.py        # ML model training/selection
│   ├── calibration.py   # probability calibration/thresholds
│   ├── evaluation.py    # metrics and baselines
│   ├── validation.py    # walk-forward validation
│   ├── live.py          # real-day replay/live-moment forecast
│   ├── main.py          # forecast orchestration
│   ├── common.py        # shared forecast configuration
│   ├── api.py           # public forecast interface
│   └── run.py           # forecast entry point
│
├── requirements.txt
├── LICENSE
└── .gitignore
```

## Setup

```bash
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
```

Linux/macOS:

```bash
source .venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

## Data

Keep the actual satellite data and calibration files outside GitHub unless their redistribution is explicitly permitted.

Expected local resources include:

```text
Dataset SOLEXS/    SoLEXS .pi / .lc files
 dataset HEL1OS/   HEL1OS FITS files
Tools/              ISRO CALDB ARF/RMF files
physics_output/     generated reports and trained models
```

Update the configured local paths in the project's configuration if required.

## Run

### Nowcast

```bash
python -m nowcast.run
```

### Forecast

```bash
python -m forecast.run
```

The forecast pipeline supports training and replaying a real date as a live hindcast, with the data hard-truncated at the selected forecast time to avoid future leakage.

## Forecast design

The forecaster uses the previous 30 minutes of observations to predict a significant flare beginning within the following 30 minutes. Training uses time-ordered data rather than a random split. Physics-informed features include SoLEXS flux and spectral information, HEL1OS hard-X-ray information, cross-instrument relationships, flare-history information, data quality and calibrated temperature trends.

## Evaluation

The project reports metrics against baseline methods and includes walk-forward validation. The current reported result is a walk-forward TSS of **+0.358** versus **+0.023** for the persistence baseline on the stated held-out evaluation.

Because the available evaluation set is small, these results should be interpreted as evidence from the available real observations rather than a guarantee of performance on all future solar activity.

## Important limitation

A "significant" flare is defined by the project's local-background criterion rather than by GOES class. Per-GOES-class probabilities are therefore not provided by the current system.

## License

This repository currently uses the MIT License. **Before the official hackathon submission, confirm that this license and repository visibility comply with the Bharatiya Antariksh Hackathon 2026 submission requirements and with the redistribution terms of any third-party calibration/data files.**
